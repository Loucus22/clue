var casty = [];
var Peacock = getColumn("cast", "Peacock");
var Plum = getColumn("cast", "Plum");
var Role = getColumn("cast", "Role");
var scecast = getColumn("scenes", "cast");
var scenum = getColumn("scenes", "scenenum");
onEvent("button1", "click", function( ) {
  for (var i = 0; i < 10; i++) {
    if (getProperty(Peacock[i].toLowerCase(), "checked") && getProperty(Plum[i].toLowerCase(), "checked")) {
      appendItem(casty, "Either");
    } else if (getProperty(Peacock[i].toLowerCase(), "checked") == false && getProperty(Plum[i].toLowerCase(), "checked") == false) {
      appendItem(casty, "Doesn't Matter");
    } else if (getProperty(Peacock[i].toLowerCase(), "checked")) {
      appendItem(casty, Peacock[i]);
    } else {
      appendItem(casty, Plum[i]);
    }
  }
  if (getProperty("lev", "checked")) {
    appendItem(casty, "Lev");
  } else {
    appendItem(casty, "Doesn't Matter");
  }
  setScreen("screen3");
  newer = casty;
});
onEvent("button2", "click", function( ) {
  var numbs = [];
  for (var i = 1; i < 15; i++) {
    if (getChecked(i + "d")) {
      appendItem(numbs, i);
    }
  }
  var ran = randomNumber(1, numbs.length);
  var Scene = numbs[ran-1];
  setText("label12", "Scene: " + Scene);
  var cast = scecast[(scenum.indexOf(Scene))];
  for (var i = 1; i < 12; i++) {
    if (!cast.includes("," + (i + ","))) {
      removeItem(casty, i-1);
      insertItem(casty, i-1, "N/A");
    }
  }
  setScreen("screen2");
  choose();
});
function choose() {
  var final = newer;
  for (var i = 0; i < 11; i++) {
    if (final[i] == "Either") {
      var rand = randomNumber(1, 2);
      removeItem(final, i);
      if (rand == 1) {
        insertItem(final, i, Peacock[i]);
      } else {
        insertItem(final, i, Plum[i]);
      }
    }
  }
  for (var i = 0; i < 11; i++) {
    setText("label11", getText("label11") + ("\n" + ((Role[i] + ": ") + final[i])));
  }
}
